# iRobot® Create® 3 Nodes

This package contains a set of nodes used for simulating a iRobot® Create® 3 robot.
Each node is defined in its own shared library and registered using `rclcpp_components` to allow run-time composition in applications.
